/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Node.cpp
 * Author: wy
 * 
 * Created on March 18, 2019, 8:56 AM
 */

#include "Node.h"

#include "Visitor.h"


Node::Node(unsigned int value):m_value(value){}

unsigned int Node::getValue() const{
    return m_value;
}

