/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NonStackBasedSumVisitor.h
 * Author: wy
 *
 * Created on March 18, 2019, 8:57 AM
 */

#ifndef NONSTACKBASEDSUMVISITOR_H
#define NONSTACKBASEDSUMVISITOR_H
#include "Node.h"
#include <stack>
#include "Visitor.h"

class NonStackBasedSumVisitor :public Visitor {
protected:
    unsigned int sum;
public:
    NonStackBasedSumVisitor();
    virtual ~NonStackBasedSumVisitor(){};
    virtual void VisitTerminalNode(TerminalNode* trn);
    virtual void VisitNonTerminalNode(NonTerminalNode* ntrn);
    double getResult();
private:
    NonStackBasedSumVisitor(const NonStackBasedSumVisitor& orig){};

};

#endif /* NONSTACKBASEDSUMVISITOR_H */

