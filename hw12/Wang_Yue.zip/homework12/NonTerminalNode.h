/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NonTerminalNode.h
 * Author: wy
 *
 * Created on March 18, 2019, 8:56 AM
 */

#ifndef NONTERMINALNODE_H
#define NONTERMINALNODE_H
#include "Node.h"
#include <vector>
#include <iostream>
#include <algorithm>

class NonTerminalNode: public Node{
protected:
    std::vector<Node*> nodes;
public:
    NonTerminalNode(unsigned int value);
    virtual ~NonTerminalNode(){};  
    virtual void Accept(Visitor* v);
    virtual void addChild(Node* node);
    virtual Node* getChildren(int i)const;
    virtual unsigned int getChildernSize() const;

    
};

#endif /* NONTERMINALNODE_H */

