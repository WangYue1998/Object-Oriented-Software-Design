/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   TerminalNode.h
 * Author: wy
 *
 * Created on March 18, 2019, 8:56 AM
 */

#ifndef TERMINALNODE_H
#define TERMINALNODE_H
#include "Node.h"
#include <iostream>
#include <vector>
class TerminalNode : public Node{
public:
    TerminalNode(unsigned int value);
    virtual ~TerminalNode(){};
    virtual void Accept(Visitor* v);

};

#endif /* TERMINALNODE_H */

