#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "observerdialog.h"
#include "ui_observerdialog.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->horizontalSlider->setMinimum(0);
    ui->horizontalSlider->setMaximum(100);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_CreateButton_clicked()
{
    observerdialog* newListener = new observerdialog(this);
    listeners.push_back(newListener);
    newListener->show();
    connect(ui->horizontalSlider, SIGNAL(valueChanged(int)),newListener->getUi()->ProgressLabel, SLOT(setNum(int)));
    connect(newListener,SIGNAL(reset(int)),ui->horizontalSlider,SLOT(setValue(int)));

}

void MainWindow::on_DeleteButton_clicked()
{
    if(listeners.size()>0){
    observerdialog* lastListener = listeners.back(); lastListener->close();
    listeners.pop_back();
    }
}
