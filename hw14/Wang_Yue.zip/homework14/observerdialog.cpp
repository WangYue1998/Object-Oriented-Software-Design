#include "observerdialog.h"
#include "ui_observerdialog.h"

#include "mainwindow.h"
#include "ui_mainwindow.h"

observerdialog::observerdialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::observerdialog)
{
    ui->setupUi(this);
    ui->ProgressLabel->setNum(0);
}

observerdialog::~observerdialog()
{
    delete ui;
}

void observerdialog::on_ResetButton_clicked()
{
    emit(reset(0));

}
