#ifndef OBSERVERDIALOG_H
#define OBSERVERDIALOG_H

#include <QDialog>

namespace Ui {
class observerdialog;
}

class observerdialog : public QDialog
{
    Q_OBJECT

public:
    explicit observerdialog(QWidget *parent = nullptr);
    ~observerdialog();

    Ui::observerdialog* getUi()const{return ui;}

private slots:
    void on_ResetButton_clicked();

private:
    Ui::observerdialog *ui;

signals:
    void reset(int);

};

#endif // OBSERVERDIALOG_H
