#include "lineedit.h"

void LineEdit::showFont(QFont font){
//    this->setText(font.family());
}
