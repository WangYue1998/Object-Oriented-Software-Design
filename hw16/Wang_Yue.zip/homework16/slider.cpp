#include "slider.h"

void slider::setslider(int){
    emit sliderChanged(this);
}

